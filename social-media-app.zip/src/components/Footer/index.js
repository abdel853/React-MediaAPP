import './styles.scss';

export default function Footer(){
    return(
        <footer className="main">
            Made by Abdel
        </footer>
    );
}