const AboutUsIntroductionPage = () => {
    return (  
        <>
        <p>que un club" ("More than a club"). Unlike many other football clubs, the supporters own and operate Barcelona. It is the fourth-most valuable sports team in the world, worth $4.76 billion, and the world's fourth richest football club in terms of revenue, with an annual turnover of €582.1 million.[2][3] The official Barcelona anthem is the "Cant del Barça", written by Jaume Picas and Josep Maria Espinàs.[4] Barcelona traditionally play in dark shades of blue and garnet stripes, hence nicknamed Blaugrana.

Domestically, Barcelona has won a record 76 trophies: 26 La Liga, 31 Copa del Rey, fourteen Supercopa de España, three Copa Eva Duarte, and two Copa de la Liga titles, as well as being the record holder for the latter four competitions. In international c</p>
</>
    );
}
 
export default AboutUsIntroductionPage;